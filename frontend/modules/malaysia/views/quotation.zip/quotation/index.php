<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use common\models\User;
/* @var $this yii\web\View */
/* @var $searchModel frontend\modules\malaysia\models\QuotationSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Quotations';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="row">
    <div class="col-md-12">

        <div class="portlet light ">


        <div class="portlet-title">

            <div class="caption">
                <span class="caption-subject font-blue-dark bold uppercase"><?= Html::encode($this->title) ?></span>
            </div>
            <div class="actions">
                  <b><?= Html::a('Create', ['create','state_id'=>$state_id], ['class' => 'btn blue-steel']) ?></b>
             
            </div>
            <br><br>
             <?php echo $this->render('_search', ['model' => $searchModel,'state_id'=>$state_id]); ?>

        </div>

        <div class="portlet-body flip-scroll">
                    <?php Pjax::begin(); ?>    
                    <?= GridView::widget([
                            'dataProvider' => $dataProvider,
                            //'filterModel' => $searchModel,
                            'columns' => [
                                ['class' => 'yii\grid\SerialColumn'],
                                'datetime',
                                 [
                                    'label' => 'CUSTOMER',
                                    'attribute' => 'customer',
                                    'value' => 'customer.company_name'
                                 ],
                                 [
                                    'label' => 'QUOTATION NO',
                                    'attribute' => 'quotation_no',
                                    'value' => function ($data){
                                            return $data->quotation_no.$data->revise;

                                    },
                                 ],

                                /*[
                                    'label' => 'TENDER',
                                    'attribute'=>'tender',
                                    'format' => 'raw',
                                    'filter'=>array("Yes"=>"Yes","No"=>"No"),
                                    'value' => function ($model) {
                                                $var = ($model->tender == "Yes") ? "Yes" : "No";
                                                return $var;
                                      
                                           // return '<div>'.$model->id.' and other html-code</div>';
                                    },
                                ], */
                                 [
                                    'label' => 'QUOTED BY',
                                    'attribute' => 'quoted',
                                    'value' => 'quoted.username'
                                 ],
                                 /* salesman */
                                 [
                                    'label' => 'Status Quotation',
                                    'attribute' => 'status_quote',
                                    'format'=>'raw',
                                    'visible'=>User::checkMenu('85'),
                                    'value'=>function ($data) {
                                            if ($data->status_quote == '') {
                                                return '';
                                            }
                                            else{
                                                if ($data->status_quote == 'Win') {
                                                    return Html::a('<span style="">'.$data->status_quote.'</span>',['status_quote','id'=>$data->id,'state_id'=>$data->state_id],['class'=>'btn btn-sm green-meadow']);
                                                }
                                                elseif($data->status_quote == 'Lost'){
                                                    return Html::a('<span style="">'.$data->status_quote.'</span>',['status_quote','id'=>$data->id,'state_id'=>$data->state_id],['class'=>'btn btn-sm btn-danger']);
                                                }
                                                else{
                                                    return Html::a('<span style="color:black !important;">'.$data->status_quote.'</span>',['status_quote','id'=>$data->id,'state_id'=>$data->state_id],['class'=>'btn btn-sm btn-warning']);
                                                }
                                                
                                            }
                                            
                                        },
                                 ],
                                 /* indoor */
                                 [
                                    'label' => 'Status Quotation',
                                    'attribute' => 'status_quote',
                                    'format'=>'raw',
                                    'visible'=>User::checkMenu('87'),
                                    'value'=>function ($data) {
                                            if ($data->status_quote == '') {
                                                return '';
                                            }
                                            else{
                                                if ($data->status_quote == 'Win') {
                                                    return '<span class="btn btn-sm green-meadow">'.$data->status_quote.'</span>';
                                                }
                                                elseif($data->status_quote == 'Lost'){
                                                    return '<span class="btn btn-sm btn-danger">'.$data->status_quote.'</span>';
                                                }
                                                else{
                                                    return '<span class="btn btn-sm btn-warning">'.$data->status_quote.'</span>';
                                                }
                                            }
                                            
                                        },
                                 ],
                                 /* Indoor */
                                 [
                                    'label' => 'Sale Review',
                                    'attribute' => 'sales_review_datetime',
                                    'format'=>'raw',
                                    'visible'=>User::checkMenu('86'),
                                    'value'=>function ($data) {
                                            if ($data->status_quote == '') {
                                                return '';
                                            }
                                            else{
                                                return '<span>'.$data->sales_review_datetime.'<br>'.$data->sales_review.'</span>';
                                                
                                                
                                            }
                                            
                                        },
                                 ],
                                 /* Salesman */
                                 [
                                    'label' => 'Sale Review',
                                    'attribute' => 'sales_review_datetime',
                                    'format'=>'raw',
                                    'visible'=>User::checkMenu('88'),
                                    'value'=>function ($data) {
                                            if ($data->status_quote == '') {
                                                return '';
                                            }
                                            else{
                                                return '<span>'.$data->sales_review_datetime.'<br>'.$data->sales_review.'</span>';
                                                
                                                
                                            }
                                            
                                        },
                                 ],
             /*[
                'label' => 'REVISE BY',
                'attribute' => 'quoted',
                'value' => 'reviseby.username'
             ],

                                [
                                    'label' => 'STATUS',
                                    'format' => 'raw',
                                    'value' => function ($model) {

                                            if ($model->status == "Progress") {

                                                return "<span class='btn btn-xs yellow'>In Progress</span>";
                                                
                                            } else {

                                                return "<span class='btn btn-xs green-jungle'>Solve</span>";

                                            }
                                      
                                            
                                    },

                                ], */


                                [
                                    'header' => 'Action',
                                    'class' => 'yii\grid\ActionColumn',
                                    'template'=>'{quotation}',
                                        'buttons' => [
                                            /*'stock' => function ($url, $model) {
                                                return Html::a('<i class="fa fa-random"></i>',$url, [
                                                            'title' => 'Add Stock',
                                                            'class' => 'btn btn-circle btn-icon-only blue-chambray'

                                                ]);

                                            },

                                            'edit' => function ($url, $model) {
                                                return Html::a('<i class="fa fa-edit"></i>',$url, [
                                                            'title' => 'Update',
                                                            'class' => 'btn btn-circle btn-icon-only blue-chambray'
                                                ]);
                                            },

                                            'info' => function ($url, $model) {
                                                return Html::a('<i class="fa fa-file-text-o"></i>',$url, [
                                                            'title' => 'Quotation Info',
                                                            'class' => 'btn btn-circle btn-icon-only blue-chambray'
                                                ]);
                                            },*/
                                            'quotation' => function ($url, $model) {
                                                return Html::a('<i class="fa fa-file-pdf-o"></i>',$url, [
                                                            'title' => 'View Quotation',
                                                            'class' => 'btn btn-circle btn-icon-only blue-chambray',

                                                ]);
                                            },


                                        ],
                                        'urlCreator' => function ($action, $model, $key, $index) {
                                           /* if ($action === 'stock') {
                                                $url = ['quotation/stock','id'=>$model->id];
                                                return $url;
                                            }
                                            if ($action === 'edit') {
                                                $url = ['quotation/update','id'=>$model->id];
                                                return $url;
                                            }
                                            if ($action === 'info') {
                                                $url = ['quotation/info','id'=>$model->id];
                                                return $url;
                                            }*/
                                            if ($action === 'quotation') {
                                                $url = ['quotation/quotation','id'=>$model->id,'state_id'=>$model->state_id];
                                                return $url;
                                            }

                                            /*if ($action === 'delete') {
                                                $url = ['quotation/delete','id'=>$model->id];
                                                return $url;
                                            }*/
                                        }
                                    ],




                            ],
                        'tableOptions' =>[
                            'class' => 'table table-bordered table-striped table-condensed flip-content',
                        ],


                        ]); ?>
                    <?php Pjax::end(); ?>
            </div>
        </div>
    </div>
</div>